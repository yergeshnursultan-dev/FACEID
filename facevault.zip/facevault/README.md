# FaceVault

Protection of face biometric templates by threshold secret sharing across
distributed storage. This repository reproduces every figure and table in the
manuscript "Protection of Face Biometric Templates by Threshold Secret Sharing
across Distributed Storage: A Comparative Study of Two Schemes".

## Files

- `schemes.py` — Configuration A (NPN + CRT, ramp) and Configuration B
  (multivariate linear + verification, perfect), applied to the full protected record.
- `experiment_full.py` — reconstruction correctness, recognition (lossless check),
  bit-level leakage, attack suite, baseline comparison, storage breakdown, timing,
  reliability, and unlinkability. Writes `results_full.json`.
- `make_figures.py` — regenerates the figures into `figs/`.
- `run_lfw_benchmark.py` — runs the full pipeline on the LFW verification benchmark
  (needs internet access and a face encoder).
- `results_full.json` — raw numerical results.
- `figs/` — generated figures.

## Environment

Intel Xeon @ 2.80 GHz (1 vCPU), Ubuntu 24.04.4 LTS, Python 3.12.3,
numpy 2.4.4, scipy 1.17.1, matplotlib 3.10.8. Fixed random seed 42.

## Usage

```
pip install -r requirements.txt
python3 experiment_full.py
python3 make_figures.py
python3 run_lfw_benchmark.py --encoder ArcFace
```

## Parameters

- (n, k) = (5, 3).
- Configuration A: irreducible degree-6 GF(2) bases {67, 87, 103, 109, 115};
  16-bit working blocks with a leading marker bit; ramp leakage 6 bits (1 share)
  or 12 bits (2 shares) per block.
- Configuration B: prime field GF(2^521 - 1); k = 3 secret chunks; per-share
  verification tags UH, signUH, SH with a per-participant key SK.
- Cryptography: SHAKE-256 keystream, BLAKE2b-128 authentication tag, SHA-256 share tags.
